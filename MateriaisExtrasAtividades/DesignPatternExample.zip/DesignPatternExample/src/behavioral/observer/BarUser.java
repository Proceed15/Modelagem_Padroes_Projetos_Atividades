package behavioral.observer;

public class BarUser<T> implements OurObserver<T> {

    private T state;

    @Override
    public void update(T obj) {
        System.out.println("Sono " + getClass().getSimpleName() +
                " ricevuto cambiamento di stato da " + state + " a " + obj);
    }
}
