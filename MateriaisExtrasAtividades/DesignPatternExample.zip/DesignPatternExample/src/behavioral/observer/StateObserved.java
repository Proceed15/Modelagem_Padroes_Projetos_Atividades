package behavioral.observer;

@Subject
public class StateObserved<T> extends OurObservable<T> {

    public void setState(T state) {
        setChanged(state);
    }

}
