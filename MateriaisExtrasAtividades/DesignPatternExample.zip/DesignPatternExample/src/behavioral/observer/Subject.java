package behavioral.observer;

public @interface Subject {

}
