package behavioral.observer;

public interface OurObserver<T> {
    void update(T obj);
}
