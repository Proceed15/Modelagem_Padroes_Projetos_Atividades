package behavioral.observer;

import java.util.ArrayList;
import java.util.List;

public class OurObservable<T> {

    private List<OurObserver> observers = new ArrayList<>();
    private T state;

    public void addObserver(OurObserver observer) {
        observers.add(observer);
    }

    public void deleteObserver(OurObserver observer) {
        observers.remove(observer);
    }

    public void setChanged(T state) {
        this.state = state;
        notifyObservers();
    }

    public void notifyObservers() {
        observers.forEach(observer -> observer.update(state));
    }

    public T getState() {
        return state;
    }
}
