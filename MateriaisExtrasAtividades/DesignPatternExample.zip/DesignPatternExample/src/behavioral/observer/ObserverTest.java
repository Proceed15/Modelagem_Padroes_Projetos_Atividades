package behavioral.observer;

public class ObserverTest {

    public static void main(String[] args) {
        StateObserved<Integer> subject = new StateObserved<>();
        FooUser<Integer> foo = new FooUser<>();
        BarUser<Integer> bar = new BarUser<>();
        subject.addObserver(foo);
        subject.addObserver(bar);

        subject.setState(10);
    }
}
