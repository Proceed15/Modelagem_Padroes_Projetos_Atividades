package behavioral.command;

public class Receiver {

    public void op1() {
        System.out.println("First op");
    }

    public void op2() {
        System.out.println("Second op");
    }
}
