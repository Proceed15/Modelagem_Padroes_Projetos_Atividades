package behavioral.command;

public class SecondCommand implements Command {

    private Receiver rec;

    public SecondCommand(Receiver rec) {
        this.rec = rec;
    }

    @Override
    public void execute() {
        rec.op2();
    }
}
