package behavioral.command;

public class Client {
    public static void main(String[] args) {
        Receiver receiver = new Receiver();
        FirstCommand firstCommand = new FirstCommand(receiver);
        SecondCommand secondCommand = new SecondCommand(receiver);
        Invoker invoker = new Invoker();

        invoker.perform(firstCommand);
        invoker.perform(secondCommand);
    }
}
