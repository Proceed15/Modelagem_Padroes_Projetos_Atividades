package behavioral.command;

public class Invoker {

    public void perform(Command command) {
        command.execute();
    }
}
