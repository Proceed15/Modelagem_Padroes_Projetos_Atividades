package behavioral.command.Servlet;

public interface HttpMethod {
    void execute();
}
