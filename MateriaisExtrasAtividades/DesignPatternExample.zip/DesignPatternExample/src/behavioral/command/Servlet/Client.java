package behavioral.command.Servlet;

public class Client {
    public static void main(String[] args) {
        HelloServlet helloServlet = new HelloServlet();
        HttpMethodGET get = new HttpMethodGET(helloServlet);
        HttpMethodPOST post = new HttpMethodPOST(helloServlet);
        Coyote coyote = new Coyote();

        coyote.perform(get);
        coyote.perform(post);


    }
}
