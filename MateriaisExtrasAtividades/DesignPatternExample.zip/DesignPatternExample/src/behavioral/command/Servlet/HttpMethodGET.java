package behavioral.command.Servlet;

public class HttpMethodGET implements HttpMethod {

    private HelloServlet rec;

    public HttpMethodGET(HelloServlet rec) {
        this.rec = rec;
    }

    @Override
    public void execute() {
        rec.doGet();
    }
}
