package behavioral.command.Servlet;

public class HelloServlet {

    public void doGet() {
        System.out.println("GET operation");
    }

    public void doPost() {
        System.out.println("POST operation");
    }
}
