package behavioral.command.Servlet;

public class HttpMethodPOST implements HttpMethod {

    private HelloServlet rec;

    public HttpMethodPOST(HelloServlet rec) {
        this.rec = rec;
    }

    @Override
    public void execute() {
        rec.doPost();
    }
}
