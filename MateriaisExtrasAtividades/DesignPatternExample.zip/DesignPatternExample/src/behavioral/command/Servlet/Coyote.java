package behavioral.command.Servlet;

public class Coyote {
    public void perform(HttpMethod httpMethod) {
        httpMethod.execute();
    }
}
