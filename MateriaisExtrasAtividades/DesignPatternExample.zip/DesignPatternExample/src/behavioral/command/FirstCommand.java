package behavioral.command;

public class FirstCommand implements Command {

    private Receiver rec;

    public FirstCommand(Receiver rec) {
        this.rec = rec;
    }

    @Override
    public void execute() {
        rec.op1();
    }
}
