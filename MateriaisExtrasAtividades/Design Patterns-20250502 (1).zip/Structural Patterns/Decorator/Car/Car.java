public interface Car {
public void assemble();
}