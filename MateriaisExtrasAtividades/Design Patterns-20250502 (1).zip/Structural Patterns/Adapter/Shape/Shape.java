interface Shape
{
  void draw(int x1, int y1, int x2, int y2);
}