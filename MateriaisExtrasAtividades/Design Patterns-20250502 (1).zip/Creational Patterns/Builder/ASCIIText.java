// Product
class ASCIIText{
	public void append(char c){ //Implement the code here }
}
