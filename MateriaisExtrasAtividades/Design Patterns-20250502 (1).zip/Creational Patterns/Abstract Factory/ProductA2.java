class ProductA2 extends AbstractProductA{
	ProductA2(String arg){
		System.out.println(“Hello ” +arg);
	} // Implement the code here
	public void operationA1() { };
	public void operationA2() { };
}
