class ProductB1 extends AbstractProductB{
	ProductB1(String arg){
		System.out.println(“Hello ” +arg);
	} // Implement the code here
}
