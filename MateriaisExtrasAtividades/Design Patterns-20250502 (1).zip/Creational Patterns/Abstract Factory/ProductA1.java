class ProductA1 extends AbstractProductA{
	ProductA1(String arg){
		System.out.println(“Hello ” +arg);
	} // Implement the code here
	public void operationA1() { };
	public void operationA2() { };
}
