class ProductB2 extends AbstractProductB{
	ProductB2(String arg){
		System.out.println(“Hello ” +arg);
	} // Implement the code here
}
