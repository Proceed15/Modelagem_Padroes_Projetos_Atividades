abstract class AbstractProductB{
	//public abstract void operationB1();
	//public abstract void operationB2();
}
