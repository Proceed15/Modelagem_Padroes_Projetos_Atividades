abstract class AbstractProductA{
	public abstract void operationA1();
	public abstract void operationA2();
}
