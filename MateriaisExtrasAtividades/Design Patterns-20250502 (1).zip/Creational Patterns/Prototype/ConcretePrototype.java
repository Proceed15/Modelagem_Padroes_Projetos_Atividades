public class ConcretePrototype implements Prototype {
			public Object clone() {
				return super.clone();
			}
		}
