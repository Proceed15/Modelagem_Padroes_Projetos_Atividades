/** Concrete Prototypes to clone **/
 public class CoconutCookie extends Cookie { }
