public interface Prototype {
			public abstract Object clone ( );
		}
		
