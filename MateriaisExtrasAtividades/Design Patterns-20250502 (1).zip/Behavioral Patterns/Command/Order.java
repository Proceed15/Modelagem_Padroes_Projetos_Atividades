public interface Order {
    public abstract void execute();
}