public interface State {
public void doAction();
}