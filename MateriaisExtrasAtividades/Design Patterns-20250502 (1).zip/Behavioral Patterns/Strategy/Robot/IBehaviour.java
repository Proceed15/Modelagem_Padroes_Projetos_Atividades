public interface IBehaviour {
	public int moveCommand();
}