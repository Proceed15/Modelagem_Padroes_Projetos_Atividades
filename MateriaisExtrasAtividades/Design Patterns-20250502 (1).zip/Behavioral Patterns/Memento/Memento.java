public interface Memento {
public void restoreState();
}
