public interface IObservador
{
    void Atualizar(float temperatura);
}
